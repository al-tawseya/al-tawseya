# -*- coding: utf-8 -*-
"""اختبارات استخراج النية والتوصية — التوصية v2."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app  # noqa: E402


def intent(q):
    return app.extract_intent(q, use_ai=False)


# ---- الحالات الـ 12 من تقرير الفحص ----

def test_case_1_dress_black_hard_max():
    i = intent("بدي فستان اسود لحفلة مرتب وفخم بس مش مبالغ وما يتجاوز 30 دينار")
    assert "clothes" in i["categories"]
    assert "black" in i["colors"]
    assert i["budget"]["kind"] == "hard_max"
    assert i["budget"]["amount"] == 30.0


def test_case_2_formal_arabic():
    i = intent("أريد فستانًا أسود أنيقًا")
    assert "clothes" in i["categories"]
    assert "black" in i["colors"]


def test_case_3_english_mix():
    i = intent("بدي black dress يكون classy")
    assert "clothes" in i["categories"]
    assert "black" in i["colors"]
    assert "luxury" in i["styles"]


def test_case_4_soft_target():
    i = intent("بدي شي حوالي 30 وإذا الجودة أفضل ممكن أزيد")
    assert i["budget"]["kind"] == "soft_target"
    assert i["budget"]["amount"] == 30.0


def test_case_5_hard_max_wont_pay_more():
    i = intent("ما بدفع أكثر من 30")
    assert i["budget"]["kind"] == "hard_max"
    assert i["budget"]["amount"] == 30.0


def test_case_6_cheapest():
    i = intent("بدي الأرخص")
    assert i["budget"]["kind"] == "cheapest"
    assert i["priority"] == "cheapest"


def test_case_7_quality_first():
    i = intent("السعر مش مهم أهم شيء الجودة")
    assert i["budget"]["kind"] == "quality_first"
    assert i["priority"] == "quality"


def test_case_8_excluded_color():
    i = intent("ما بدي أسود")
    assert "black" in i["excluded_colors"]
    assert "black" not in i["colors"]


def test_case_9_shoe_eu_size():
    i = intent("أنا 38 أوروبي بدي شوز كعبه واطي")
    assert "shoes" in i["categories"]
    assert i["sizes"]["system"] == "shoe_eu"
    assert i["sizes"]["value"] == 38


def test_case_10_bra_size():
    i = intent("بدي برا 34C")
    assert "lingerie" in i["categories"]
    assert i["sizes"]["system"] == "bra"
    assert i["sizes"]["band"] == 34
    assert i["sizes"]["cup"] == "C"


def test_case_11_scarf_long_wide():
    i = intent("بدي شال طويل وعريض")
    assert "scarves" in i["categories"]


def test_case_12_brand_reference():
    i = intent("بدي شي مثل Zara")
    assert i["brand_soft"] == "Zara"


# ---- سلوك التوصية (Hard filters) ----

def test_recommend_shoes_returns_shoes_not_makeup():
    i = intent("أنا 38 أوروبي بدي شوز")
    results = app.recommend(i)
    assert results, "يجب أن توجد نتائج أحذية"
    assert all(r["category"] == "shoes" for r in results)
    assert any("38" in r["sizes"] for r in results)


def test_recommend_bra_returns_lingerie():
    i = intent("بدي برا 34C")
    results = app.recommend(i)
    assert results
    assert all(r["category"] == "lingerie" for r in results)
    assert any("34C" in [s.upper() for s in r["sizes"]] for r in results)


def test_recommend_hard_max_filters_price():
    i = intent("بدي فستان أسود ما يتجاوز 30 دينار")
    results = app.recommend(i)
    assert results
    assert all(r["price_jod"] <= 30.0 for r in results)


def test_recommend_excluded_color_removed():
    i = intent("بدي فستان ما بدي أسود")
    results = app.recommend(i)
    assert all("black" not in r["colors"] for r in results)


def test_recommend_scarf_excludes_chiffon():
    i = intent("بدي شال طويل ومش شيفون")
    results = app.recommend(i)
    assert results
    assert all("شيفون" not in (r["title"] + r["description"] + " ".join(r["tags"])) for r in results)


def test_recommend_has_reasons():
    i = intent("بدي فستان أسود تحت 30")
    results = app.recommend(i)
    assert results
    assert all(isinstance(r["reasons"], list) and r["reasons"] for r in results)


def test_refine_cheapest_resorts():
    i = intent("بدي فستان أسود")
    refined = app.refine_intent(i, "بدي أرخص")
    assert refined["priority"] == "cheapest"
    results = app.recommend(refined)
    prices = [r["price_jod"] for r in results]
    assert prices == sorted(prices)


def test_refine_drop_color():
    i = intent("بدي فستان أسود")
    refined = app.refine_intent(i, "مش شرط الأسود")
    assert "black" not in refined["colors"]
